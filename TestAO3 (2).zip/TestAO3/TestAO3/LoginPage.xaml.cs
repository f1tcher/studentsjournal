﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TestAO3
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class LoginPage : Window
    {
       
        public LoginPage()
        {
            InitializeComponent();

            
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string login = Login.Text;
            string password = Password.Password;
            MySqlDataBase users = new MySqlDataBase();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand command = new MySqlCommand("SELECT * FROM students.users " +
                $"WHERE login = '{login}' AND password = '{password}'", users.getConnection());
            
            adapter.SelectCommand = command;
            adapter.Fill(table);
            if (login.Length > 0 && password.Length > 0)
            {
                if (table.Rows.Count > 0)
                {
                    MessageBox.Show($"{table.Rows[0][3]}, добро пожаловать!\nВаша роль - {table.Rows[0][5]}");
                    StudentJournal studentJournal = new StudentJournal();
                    studentJournal.Show();
                    this.Close();
                }
                else ErrorLogin.Text = "Логин или пароль введены неверно";
            }
            else ErrorLogin.Text = "Введите данные от аккаунта";
        }

        private void GoToRegisterPage_Click(object sender, RoutedEventArgs e)
        {
            RegisterPage registerPage = new RegisterPage();
            registerPage.Show();
            this.Close();
        }
    }
}
