﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestAO3
{
    internal class MySqlDataBase
    {
        MySqlConnection studentsdb = new MySqlConnection("server=localhost;port=3306;username=root;password=Energetic228;database=students");

        public void openConnection()
        {
            if(studentsdb.State == System.Data.ConnectionState.Closed) 
            { 
                studentsdb.Open();
            }
        }
        
        public void closeConnection()
        {
            if(studentsdb.State == System.Data.ConnectionState.Open) 
            { 
                studentsdb.Close();
            }
        }

        public MySqlConnection getConnection()
        {
            return studentsdb;
        }
    }
}
