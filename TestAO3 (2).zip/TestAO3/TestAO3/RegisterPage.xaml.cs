﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TestAO3
{
    /// <summary>
    /// Логика взаимодействия для RegisterPage.xaml
    /// </summary>
    public partial class RegisterPage : Window
    {
        public string typeUser = "";
        public RegisterPage()
        {
            InitializeComponent();
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {

            MySqlDataBase users = new MySqlDataBase();
            MySqlCommand command = new MySqlCommand("INSERT INTO `students`.`users` (`login`, `password`, `name`, `surname`, `type`) " +
                "VALUES (@login, @password, @name , @surname , @type);", users.getConnection());



            command.Parameters.Add("@login", MySqlDbType.VarChar).Value = Login.Text;
            command.Parameters.Add("@password", MySqlDbType.VarChar).Value = Password.Password;
            command.Parameters.Add("@name", MySqlDbType.VarChar).Value = NameBox.Text;
            command.Parameters.Add("@surname", MySqlDbType.VarChar).Value = SurnameBox.Text;
            command.Parameters.Add("@type", MySqlDbType.VarChar).Value = typeUser;

            users.openConnection();

            if (Login.Text.Length > 0 && Password.Password.Length > 0 && NameBox.Text.Length > 0 && SurnameBox.Text.Length > 0 && typeUser.Length > 0)
            {
                if (Password.Password == PasswordConfirm.Password)
                {
                    if (userComparison())
                    {
                        if (command.ExecuteNonQuery() == 1)
                        {
                            MessageBox.Show("Вы успешно зарегистрировались!");
                            GoToLogin();
                            users.closeConnection();
                        }
                        else ErrorRegister.Text = "Данные имеют недопустимый формат";
                    }
                    else ErrorRegister.Text = "Пользователь с таким логином уже существует";
                }
                else ErrorRegister.Text = "Пароли не совпадают";
            }
            else ErrorRegister.Text = "Введите все данные";

            users.closeConnection();
        }

        public bool userComparison()
        {
            MySqlDataBase users = new MySqlDataBase();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand command = new MySqlCommand("SELECT * FROM students.users " +
                $"WHERE login = @login ", users.getConnection());

            command.Parameters.Add("@login", MySqlDbType.VarChar).Value = Login.Text;

            adapter.SelectCommand = command;
            adapter.Fill(table);

            if (table.Rows.Count > 0)
            {               
                return false;
            }
            return true;

        }

        private void SurnameBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void NameBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void ValidateInput(object sender, TextCompositionEventArgs e)
        {
            TextBox textBox = sender as TextBox;

            if (textBox != null)
            {
                char inputChar = e.Text.ToCharArray()[0];

                
                if (char.IsLetter(inputChar))
                {
                    e.Handled = false; 
                }
                else
                {
                    e.Handled = true;                   
                }
            }
        }

        private void TeacherReg_Checked(object sender, RoutedEventArgs e)
        {
            typeUser = "teacher";
        }

        private void StudentReg_Checked(object sender, RoutedEventArgs e)
        {
            typeUser = "student";
        }

        private void ParentReg_Checked(object sender, RoutedEventArgs e)
        {
            typeUser = "parent";
        }

        private void GoLogin_Click(object sender, RoutedEventArgs e)
        {
            GoToLogin();
        }

        private void GoToLogin()
        {
            LoginPage loginPage = new LoginPage();
            loginPage.Show();
            this.Close();
        }
    }
}
