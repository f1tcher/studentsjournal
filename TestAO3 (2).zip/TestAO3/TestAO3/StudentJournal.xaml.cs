﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TestAO3
{
    /// <summary>
    /// Логика взаимодействия для StudentJournal.xaml
    /// </summary>
    public partial class StudentJournal : Window
    {
        public StudentJournal()
        {
            InitializeComponent();
            DataTable table = GetTableDatabase();
            for (int i = 0;i<table.Rows.Count; i++)
            {
                if (table.Rows[i][2].ToString() == "student")
                { 
                UsersList.Text += table.Rows[i][0].ToString() + " " + table.Rows[i][1].ToString() + "\n";
                }
            }
        }

        public DataTable GetTableDatabase()
        {
            MySqlDataBase users = new MySqlDataBase();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            MySqlCommand command = new MySqlCommand("SELECT name, surname, type FROM students.users", users.getConnection());

            adapter.SelectCommand = command;
            adapter.Fill(table);

            return table;
        }


    }
}
